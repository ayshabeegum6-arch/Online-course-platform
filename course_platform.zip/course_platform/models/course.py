from odoo import models,fields


class Instructor(models.Model):
    _name = 'course.instructor'
    _description = 'Instructor'

    name=fields.Char(string='Name',required=True)
    phone=fields.Char(string='Phone')
    email = fields.Char(string='Email')
    image=fields.Image(string='Image')
    bio=fields.Text(string='Bio')
    course_ids = fields.One2many('course.course','instructor_id',
        string='Course')


class Course(models.Model):
    _name = 'course.course'
    _description = 'Course'

    name = fields.Char(
        string='Course Name',
        required=True
    )

    instructor_id = fields.Many2one(
        'course.instructor',
        string='Instructor',
        required=True
    )

    price = fields.Float(
        string='Price'
    )

    duration = fields.Char(
        string='Duration'
    )


    description = fields.Text(
        string='Description'
    )

    image = fields.Image(
        string='Course Image'
    )

    lesson_ids = fields.One2many(
        'course.lesson',
        'course_id',
        string='Lessons'
    )

    enrollment_ids = fields.One2many(
        'course.enrollment',
        'course_id',
        string='Enrollments'
    )

class Lesson(models.Model):
    _name = 'course.lesson'
    _description = 'Lesson'
    _order = 'sequence, id'

    name = fields.Char(
        string='Lesson Name',
        required=True
    )

    course_id = fields.Many2one(
        'course.course',
        string='Course',
        required=True,
        ondelete='cascade'
    )

    sequence = fields.Integer(
        string='Sequence',
        default=1
    )

    description = fields.Text(
        string='Description'
    )


    duration = fields.Char(
        string='Duration'
    )

class Enrollment(models.Model):
    _name = 'course.enrollment'
    _description = 'Enrollment'

    student_id = fields.Many2one(
        'res.users',
        string='Student',
        required=True
    )

    course_id = fields.Many2one(
        'course.course',
        string='Course',
        required=True
    )

    enrollment_date = fields.Date(
        string='Enrollment Date',
        default=fields.Date.today,
        required=True
    )

    status = fields.Selection([
        ('enrolled', 'Enrolled'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ],
        string='Status',
        default='enrolled'
    )



    _sql_constraints = [
        (
            'unique_student_course',
            'unique(student_id, course_id)',
            'This student is already enrolled in this course.'
        )
    ]