from odoo import http
from odoo.http import request


class CourseWebsite(http.Controller):


    @http.route(
        '/courses',
        type='http',
        auth='public',
        website=True
    )
    def courses(self):

        courses = request.env['course.course'].sudo().search([])

        return request.render(
            'course_platform.courses_page',
            {
                'courses': courses,
            }
        )

    @http.route(
        '/courses/<int:course_id>',
        type='http',
        auth='public',
        website=True
    )
    def course_detail(self, course_id):

        course = request.env['course.course'].sudo().browse(course_id)

        if not course.exists():
            return request.not_found()

        return request.render(
            'course_platform.course_detail_page',
            {
                'course': course,
            }
        )


    @http.route(
        '/courses/<int:course_id>/enroll',
        type='http',
        auth='user',
        website=True
    )
    def enroll_course(self, course_id):

        course = request.env['course.course'].sudo().browse(course_id)

        if not course.exists():
            return request.not_found()

        existing = request.env['course.enrollment'].sudo().search([
            ('student_id', '=', request.env.user.id),
            ('course_id', '=', course.id),
        ], limit=1)

        if not existing:
            request.env['course.enrollment'].sudo().create({
                'student_id': request.env.user.id,
                'course_id': course.id,
            })

        return request.redirect(
            f'/courses/{course.id}'
        )


    @http.route(
        '/instructors',
        type='http',
        auth='public',
        website=True
    )
    def instructors(self):

        instructors = request.env[
            'course.instructor'
        ].sudo().search([])

        return request.render(
            'course_platform.instructors_page',
            {
                'instructors': instructors,
            }
        )

    @http.route(
        '/instructors/<int:instructor_id>',
        type='http',
        auth='public',
        website=True
    )
    def instructor_detail(self, instructor_id):

        instructor = request.env[
            'course.instructor'
        ].sudo().browse(instructor_id)

        if not instructor.exists():
            return request.not_found()

        return request.render(
            'course_platform.instructor_detail_page',
            {
                'instructor': instructor,
            }
        )

    @http.route(
        '/lessons',
        type='http',
        auth='public',
        website=True
    )
    def lessons(self):

        lessons = request.env[
            'course.lesson'
        ].sudo().search(
            [],
            order='sequence asc'
        )

        return request.render(
            'course_platform.lessons_page',
            {
                'lessons': lessons,
            }
        )


    @http.route(
        '/lessons/<int:lesson_id>',
        type='http',
        auth='public',
        website=True
    )
    def lesson_detail(self, lesson_id):

        lesson = request.env[
            'course.lesson'
        ].sudo().browse(lesson_id)

        if not lesson.exists():
            return request.not_found()

        return request.render(
            'course_platform.lesson_detail_page',
            {
                'lesson': lesson,
            }
        )


    @http.route(
        '/enrollment',
        type='http',
        auth='user',
        website=True
    )
    def my_enrollments(self):

        enrollments = request.env[
            'course.enrollment'
        ].sudo().search([
            ('student_id', '=', request.env.user.id)
        ], order='id desc')

        return request.render(
            'course_platform.enrollments_page',
            {
                'enrollments': enrollments,
            }
        )