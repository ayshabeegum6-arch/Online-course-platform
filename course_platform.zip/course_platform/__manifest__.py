{
    'name': 'Course Platform',
    'version': '19.0.1.0',
    'author': 'Aysha Beegum',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'website',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/course_views.xml',
        'views/website_templates.xml',
    ],
    'installable': True,
    'application': True,
}